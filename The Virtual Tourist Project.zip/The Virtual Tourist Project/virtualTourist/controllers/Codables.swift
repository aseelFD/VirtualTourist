//
//  Codables.swift
//  virtualTourist
//
//  Created by MAC on 13/06/1440 AH.
//  Copyright © 1440 MAC. All rights reserved.
//

import Foundation


struct AlbumResponse : Codable {
    var photos : Photos
    var stat : String
}

struct Photos : Codable {
    var photo : [PhotoList]
}

struct PhotoList : Codable {
    var id : String
    var server : String
    var secret : String
    var farm : Int
    var url : String {
        return "https://farm\(farm).staticflickr.com/\(server)/\(id)_\(secret).jpg"
    }

}
